# AI-Based Skill Assessment Platform

## Setup Instructions

### Frontend (React)
```bash
cd frontend
npm install
npm start
```

### Backend (Express)
```bash
cd backend
npm install
npm start
```

Make sure MongoDB is set up and running if you want to connect it later.
