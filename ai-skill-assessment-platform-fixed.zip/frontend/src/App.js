import React from 'react';

function App() {
  return (
    <div>
      <h1>AI Skill Assessment Platform</h1>
      <p>Welcome to the platform!</p>
    </div>
  );
}

export default App;
